---
name: gladly-chat-demo
description: Generate pixel-perfect Gladly Chat UI mockups for demos, presentations, and prototypes. Creates HTML, static images, or GIF-ready sequences with custom conversations.
---

# Gladly Chat Demo Generator

## Overview

This skill generates on-brand Gladly Chat UI visuals for GTM and Sales teams. It produces pixel-perfect HTML prototypes that can be used in presentations, demos, and marketing materials without needing Figma access or design skills.

## Output Formats

1. **HTML Prototype** - Interactive, copy-paste ready HTML/CSS
2. **Static Mockup** - Screenshot-ready HTML for slides (PowerPoint/Google Slides)
3. **GIF Sequence** - Step-by-step frames for animated walkthroughs

## Placement Modes

1. **Centered** - Chat UI centered on page (for focused demos)
2. **Widget** - Bottom-right positioned (for website context demos)

---

## Design System Reference

### Chat Container
```css
.gladly-chat-container {
  width: 368px;
  height: 640px;
  border-radius: 16px;
  box-shadow: 0 0 80px 0 rgba(0, 0, 0, 0.06),
              0 0 10px 0 rgba(0, 0, 0, 0.06),
              0 4px 20px 0 rgba(0, 0, 0, 0.04);
  background: #FFFFFF;
  font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
```

### Header
```css
.gladly-chat-header {
  width: 100%;
  height: 58px;
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  padding: 0 12px 8px 12px;
  border-bottom: 1px solid #CECECE;
  box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.08);
  position: relative;
}

.gladly-chat-header-title {
  color: #000000;
  text-align: center;
  font-size: 13px;
  font-weight: 700;
  line-height: 30px;
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  bottom: 9px;
}

.gladly-chat-header-back {
  color: #000000;
  font-size: 13px;
  font-weight: 400;
  line-height: 14px;
  letter-spacing: 0.2px;
  display: flex;
  align-items: center;
  padding: 8px 12px 8px 10px;
  gap: 8px;
  border-radius: 24px;
  cursor: pointer;
  background: none;
  border: none;
  transition: background-color 0.2s ease;
}

.gladly-chat-header-back:hover {
  background: #F1F1F1;
}

.gladly-chat-header-close {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 8px;
  width: 32px;
  height: 30px;
  border-radius: 24px;
  cursor: pointer;
  background: none;
  border: none;
  transition: background-color 0.2s ease;
}

.gladly-chat-header-close:hover {
  background: #F1F1F1;
}
```

### Messages Area
```css
.gladly-chat-messages {
  flex: 1;
  overflow-y: auto;
  padding: 18px;
  display: flex;
  flex-direction: column;
  gap: 4px;
}
```

### Message Groups
Message groups wrap a message bubble and its timestamp together.

```css
.gladly-message-group {
  display: flex;
  flex-direction: column;
  margin-bottom: 12px;
}

.gladly-message-group-agent {
  align-items: flex-start;
}

.gladly-message-group-consumer {
  align-items: flex-end;
}
```

**HTML Example:**
```html
<div class="gladly-message-group gladly-message-group-agent">
  <div class="gladly-message gladly-message-agent">Message text here</div>
  <div class="gladly-timestamp">1:13 pm</div>
</div>
```

---

## Agent Message Types

There are **two types** of agent message bubbles:

### 1. Standard Agent Message (with bubble)
Use this for regular agent responses with a visible bubble container.

```css
.gladly-message-agent {
  padding: 14px 15px;
  border-radius: 1px 20px 20px 20px;
  border: 1px solid #E3E3E3;
  background: #FFFFFF;
  color: #000000;
  font-size: 13px;
  font-weight: 400;
  line-height: 18px;
  letter-spacing: 0.2px;
  max-width: 95%;
  width: fit-content;
}
```

**HTML Example:**
```html
<div class="gladly-message-group gladly-message-group-agent">
  <div class="gladly-message gladly-message-agent">
    Hi there! How can I help you today?
  </div>
  <div class="gladly-timestamp">1:13 pm</div>
</div>
```

### 2. Plain Agent Message (no bubble)
Use this when displaying product cards or order cards alongside the message. The text appears without a visible bubble container.

```css
.gladly-message-agent-plain {
  border: none;
  background: transparent;
  color: #000000;
  padding: 0;
}
```

**HTML Example (with Product Cards):**
```html
<div class="gladly-message-group gladly-message-group-agent">
  <div class="gladly-message gladly-message-agent-plain">
    Here are some products you might like:
  </div>
  <div class="gladly-product-cards show">
    <!-- Product cards here -->
  </div>
  <div class="gladly-timestamp">1:13 pm</div>
</div>
```

**When to use each type:**
| Scenario | Message Type |
|----------|--------------|
| Regular text response | `.gladly-message-agent` |
| Response with product cards | `.gladly-message-agent-plain` |
| Response with order cards | `.gladly-message-agent-plain` |
| Product descriptions after cards | `.gladly-message-agent-plain` |

---

## Consumer Message Bubble
```css
.gladly-message-consumer {
  padding: 14px 15px;
  border-radius: 20px 1px 20px 20px;
  border: 1px solid rgba(0, 0, 0, 0.08);
  background: #F1F1F1;
  color: #000000;
  font-size: 13px;
  font-weight: 400;
  line-height: 18px;
  letter-spacing: 0.2px;
  max-width: 95%;
  width: fit-content;
}
```

**Note:** The `max-width: 95%` combined with `width: fit-content` constrains the bubble width while allowing text to wrap naturally.

---

## Timestamp Rules

- **Consecutive messages**: Only show timestamp on the **last message** in a consecutive sequence from the same sender
- **Standard spacing**: `margin-top: 4px` after bubble messages
- **Plain message spacing**: `margin-top: 8px` after plain agent messages (product/order cards)

```css
.gladly-timestamp {
  color: #767676;
  font-size: 11px;
  font-weight: 400;
  line-height: 12px;
  letter-spacing: 0.2px;
  margin-top: 4px;
}

/* Extra spacing after plain messages */
.gladly-message-agent-plain ~ .gladly-timestamp {
  margin-top: 8px;
}
```

---

## Product Cards

Two cards per row, used for product recommendations.

```css
.gladly-product-cards {
  display: none; /* Add 'show' class to display */
  flex-wrap: wrap;
  gap: 16px;
  padding: 8px 0;
  margin-top: 8px;
  margin-bottom: 8px;
}

.gladly-product-cards.show {
  display: flex;
}

.gladly-product-card {
  width: calc(50% - 8px);
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.gladly-product-card-image {
  width: 100%;
  aspect-ratio: 1 / 1;
  border-radius: 20px;
  border: 1px solid #E3E3E3;
  background: #F5F5F5;
  object-fit: cover;
  overflow: hidden;
}

.gladly-product-card-name {
  font-size: 13px;
  font-weight: 700;
  line-height: 18px;
  color: #000000;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
```

**HTML Example:**
```html
<div class="gladly-product-cards show">
  <div class="gladly-product-card">
    <div class="gladly-product-card-image">
      <img src="product-image.jpg" alt="Product Name">
    </div>
    <div class="gladly-product-card-name">Product Name</div>
  </div>
  <div class="gladly-product-card">
    <div class="gladly-product-card-image">
      <img src="product-image-2.jpg" alt="Product Name 2">
    </div>
    <div class="gladly-product-card-name">Product Name 2</div>
  </div>
</div>
```

---

## Order Cards

Full-width card for order status display.

```css
.gladly-order-cards {
  display: none; /* Add 'show' class to display */
  flex-direction: column;
  gap: 16px;
  padding: 8px 0;
  margin-top: 8px;
  margin-bottom: 8px;
  width: 100%;
}

.gladly-order-cards.show {
  display: flex;
}

.gladly-order-card {
  display: flex;
  flex-direction: row;
  width: 100%;
  border: 1px solid #E3E3E3;
  border-radius: 20px;
  overflow: hidden;
}

.gladly-order-card-image {
  width: 140px;
  height: 140px;
  flex-shrink: 0;
  background: #F5F5F5;
}

.gladly-order-card-details {
  display: flex;
  flex-direction: column;
  padding: 14px 16px;
}

/* Order card text styles */
.gladly-order-card-status { font-size: 13px; font-weight: 700; line-height: 162%; }
.gladly-order-card-date { font-size: 16px; font-weight: 700; line-height: 162%; text-transform: uppercase; }
.gladly-order-card-number { font-size: 13px; font-weight: 700; line-height: 162%; }
.gladly-order-card-summary { font-size: 13px; font-weight: 400; line-height: 162%; }
.gladly-order-card-tracking { display: flex; align-items: center; gap: 6px; font-size: 13px; font-weight: 700; }
.gladly-order-card-tracking a { color: #009B00; font-weight: 700; }
```

**HTML Example:**
```html
<div class="gladly-order-cards show">
  <div class="gladly-order-card">
    <div class="gladly-order-card-image">
      <img src="product-image.jpg" alt="Product">
    </div>
    <div class="gladly-order-card-details">
      <div class="gladly-order-card-status">Arriving</div>
      <div class="gladly-order-card-date">AUG 7</div>
      <div class="gladly-order-card-number">Order #GLD-78234</div>
      <div class="gladly-order-card-summary">1 item - $260.00</div>
      <div class="gladly-order-card-tracking">
        <!-- Truck icon SVG -->
        <a href="#">USPS-00064735172</a>
      </div>
    </div>
  </div>
</div>
```

---

## Quick Reply Buttons
```css
.gladly-quick-replies {
  display: none; /* Add 'show' class to display */
  flex-wrap: wrap;
  gap: 8px;
  padding: 8px 0;
}

.gladly-quick-replies.show {
  display: flex;
}

.gladly-quick-reply-btn {
  padding: 10px 16px;
  border-radius: 20px;
  border: 1px solid #E3E3E3;
  background: #FFFFFF;
  color: #000000;
  font-size: 13px;
  font-weight: 400;
  line-height: 18px;
  cursor: pointer;
  transition: background-color 0.2s ease;
}

.gladly-quick-reply-btn:hover {
  background: #F1F1F1;
}
```

---

## Typing Indicator

There are **two styles** of typing indicators to match the agent message style:

### 1. Typing Indicator with Bubble
Use this when agent messages have bubbles (standard style).

```css
.gladly-typing-indicator {
  display: none; /* Add 'show' class to display */
  align-items: center;
  gap: 4px;
  padding: 20px 18px;
  border-radius: 1px 20px 20px 20px;
  border: 1px solid #E3E3E3;
  background: #FFFFFF;
  align-self: flex-start;
  margin-bottom: 12px;
}
```

### 2. Typing Indicator Plain (no bubble)
Use this when agent messages are plain text (product recommendation style).

```css
.gladly-typing-indicator-plain {
  display: none;
  align-items: center;
  gap: 4px;
  padding: 4px 0;
  align-self: flex-start;
  margin-bottom: 12px;
}
```

### Typing Dots (shared)
```css
.gladly-typing-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #000000;
  animation: gladly-typing 1.4s infinite ease-in-out;
}

@keyframes gladly-typing {
  0%, 60%, 100% { transform: translateY(0); opacity: 0.3; }
  30% { transform: translateY(-4px); opacity: 1; }
}
```

**Important:** In static animated mode, the typing indicator is dynamically inserted RIGHT BEFORE each agent message as it appears in the sequence.

---

## System Message
Used for system notifications like "Agent joined the conversation".

```css
.gladly-system-message {
  text-align: center;
  color: #767676;
  font-size: 11px;
  font-weight: 400;
  line-height: 14px;
  padding: 8px 16px;
  margin: 8px 0;
}
```

**HTML Example:**
```html
<div class="gladly-system-message">
  Sarah joined the conversation
</div>
```

---

## Privacy Policy Text
```css
.gladly-privacy-policy {
  text-align: center;
  color: #484848;
  font-size: 11px;
  font-weight: 400;
  line-height: 16px;
  padding: 0 16px 12px 16px;
  display: none; /* Add 'show' class to display */
}

.gladly-privacy-policy a {
  color: #00A300;
  font-weight: 700;
}
```

---

## Powered by Gladly
```css
.gladly-powered-by {
  text-align: center;
  color: #484848;
  font-size: 11px;
  font-weight: 400;
  line-height: 14px;
  padding: 8px 16px;
  display: none; /* Add 'show' class to display */
}
```

---

## Link Styling

All links in messages appear bold and green:
```css
.gladly-message a {
  color: #009B00;
  text-decoration: none;
  font-weight: 700;
}
```

---

## Input Area / Footer
```css
.gladly-chat-footer {
  padding: 16px 18px;
  border-top: 1px solid #CECECE;
  box-shadow: 0 -2px 4px 0 rgba(0, 0, 0, 0.08);
  display: flex;
  align-items: center;
  gap: 12px;
}

.gladly-chat-input {
  flex: 1;
  border: none;
  outline: none;
  font-size: 13px;
  color: #000000;
}

.gladly-chat-input::placeholder {
  color: #767676;
}

/* Footer icons container */
.gladly-chat-footer-icons {
  display: flex;
  align-items: center;
  gap: 8px;
}

/* Footer button styling (attachment + send) */
.gladly-chat-attachment,
.gladly-chat-send {
  cursor: pointer;
  background: none;
  border: none;
  padding: 0;
  width: 32px;
  height: 32px;
  border-radius: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: background-color 0.2s ease;
}

.gladly-chat-attachment:hover,
.gladly-chat-send:hover {
  background: #F1F1F1;
}

/* Send button - hidden by default (static mode) */
.gladly-chat-send {
  display: none;
}
```

---

## Presentation Modes

There are **two presentation modes** for the chat demo:

### Static Mode (Default)
- Send button is **hidden**
- Messages appear pre-loaded in the chat
- Best for: Screenshots, presentations, slide decks

```html
<!-- Static mode: no 'interactive' class on footer -->
<div class="gladly-chat-footer">
  <input type="text" class="gladly-chat-input" placeholder="Type a message">
  <div class="gladly-chat-footer-icons">
    <button class="gladly-chat-attachment">...</button>
    <button class="gladly-chat-send">...</button>
  </div>
</div>
```

### Interactive Mode
- Add `interactive` class to `.gladly-chat-footer`
- Send button **appears automatically** when user types text (controlled by JS)
- Send button **hides** when input is empty
- User can type messages and click Send or press Enter
- New messages appear at the end of the conversation
- Consecutive messages from the same sender only show timestamp on the last one
- Best for: Live demos, interactive walkthroughs

```html
<!-- Interactive mode: add 'interactive' class to footer -->
<div class="gladly-chat-footer interactive">
  <input type="text" class="gladly-chat-input" placeholder="Type a message">
  <div class="gladly-chat-footer-icons">
    <button class="gladly-chat-attachment">...</button>
    <button class="gladly-chat-send">...</button>
  </div>
</div>
```

```css
/* Interactive mode CSS */
.gladly-chat-footer.interactive .gladly-chat-send {
  display: none;
}

.gladly-chat-footer.interactive .gladly-chat-send.has-text {
  display: flex;
}
```

---

## Show/Hide Components

Most components are hidden by default. Add the `show` class to display them:

| Component | Default | To Show |
|-----------|---------|---------|
| Privacy Policy | Hidden | Add `show` class |
| Quick Replies | Hidden | Add `show` class |
| Product Cards | Hidden | Add `show` class |
| Order Cards | Hidden | Add `show` class |
| Typing Indicator | Hidden | Add `show` class |
| Powered by Gladly | Hidden | Add `show` class |
| Send Button (Static) | Hidden | Add `show` class |
| Send Button (Interactive) | Hidden | Auto-shows when user types (add `interactive` class to footer) |

---

## How to Use This Skill

### Quick Start

Tell me what you need:

> "Create a Gladly chat demo for [your use case]"

I'll ask you a few quick questions to customize your demo, then generate the HTML file.

---

## Guided Setup Flow

**IMPORTANT: Before generating a prototype, ask the user these questions to gather requirements.**

### Question 1: Conversation Content
Ask: **"What's the conversation about?"**

Options:
- Describe a scenario (e.g., "customer asking about delayed shipment")
- Provide specific dialogue
- Choose a common use case:
  - Order tracking
  - Returns/refunds
  - Product recommendations
  - General support

### Question 2: Presentation Mode
Ask: **"How will you use this demo?"**

| Option | Description | Best For |
|--------|-------------|----------|
| **Static (animated)** | The conversation plays out automatically - messages appear one by one with typing indicators between agent responses. Great for recording. | GIFs, video recordings, presentations |
| **Interactive** | You control the conversation - type messages and press Send/Enter to add them to the chat. Agent messages are pre-loaded. | Live sales demos, walkthroughs |

### Question 3: Components
Ask: **"Which components do you need?"** (multi-select)

- [ ] **Product Cards** - Product recommendations with images
- [ ] **Order Card** - Order status with delivery date, tracking info
- [ ] **Privacy Policy** - Legal disclaimer text at top of chat
- [ ] **Powered by Gladly** - Branding footer at bottom
- [ ] **None of the above** - Just message bubbles

---

### Question 4: Component Details (ask based on selections above)

#### If Product Cards selected:

**4a. How many product cards?**
| Option | Layout |
|--------|--------|
| **2 cards** | Two products side by side |
| **4 cards** | Two rows of two products |

**4b. Product details:**
For each product, ask:
- "What is the product name?"
- "Please provide the product image URL. You can get this by right-clicking on the product image and selecting 'Copy Image Address'."

#### If Order Card selected:
Ask for:
- Order number (e.g., "#GLD-12345")
- Delivery status (e.g., "Arriving", "Shipped", "Delivered")
- Delivery date (e.g., "Friday, Feb 14")
- Tracking number (optional)
- Item count and price (e.g., "2 items · $156.00")

---

### Question 5: Agent Message Style
Ask: **"How should agent messages be displayed?"**

| Style | Description | Recommended For |
|-------|-------------|-----------------|
| **With bubble** | Agent messages appear inside a rounded bubble container with a border | Showcasing the existing chat experience, general support conversations |
| **Without bubble** | Agent messages appear as plain text without a container | Product recommendation conversations - keeps the UI clean when showing product cards |

**Recommendation guidance:**
- Choose **"With bubble"** if you want to showcase a typical back-and-forth chat experience
- Choose **"Without bubble"** if your demo focuses on product recommendations with product cards

**Note:** You can mix both styles in the same conversation. For example, use bubbles for greeting messages and plain text for messages that accompany product/order cards.

---

### Question 6: Placement
Ask: **"Where should the chat appear?"**

| Option | Description |
|--------|-------------|
| **Centered** | Chat UI centered on a solid background |
| **Widget** | Bottom-right corner, overlaid on a website screenshot |

**If Centered selected:**
Ask: "What background color would you like? Provide a hex code (e.g., #1a1a1a for dark, #ffffff for white)"
- Default: `#1a1a1a` (dark gray)

**If Widget selected:**
Ask: "Please provide a screenshot of the webpage where you want the widget to appear. The image should be **1440x810 pixels** for best results."
- The chat widget will be positioned in the bottom-right corner over the screenshot

---

## After Gathering Requirements

Once you have the answers, generate:
1. Complete HTML file with all requested components
2. Customized conversation content
3. Appropriate presentation mode (static animation or interactive)
4. All styling matching Gladly's design system

### Product Card Placement Rules

When including product cards in the conversation:
- **Product cards always appear BEFORE the agent's text response** that mentions them
- When the agent's message highlights or mentions a product by name, always include the product card
- The product card visually introduces the product, then the text message provides context or description

**Example structure:**
```html
<!-- Product cards appear first -->
<div class="gladly-product-cards">
  <div class="gladly-product-card">...</div>
  <div class="gladly-product-card">...</div>
</div>
<!-- Then the agent message referencing the products -->
<div class="gladly-message-group gladly-message-group-agent">
  <div class="gladly-message gladly-message-agent-plain">
    Here are two great options I'd recommend...
  </div>
</div>
```

---

## Example Prompts

**Product Recommendations:**
> "Create a chat where the agent recommends trail running shoes using product cards with descriptions"

**Order Status:**
> "Generate a chat showing order tracking with an order card displaying delivery date, order number, and tracking link"

**Basic Demo:**
> "Create a centered chat demo where a customer asks about sizing for a jacket"

**With Quick Replies:**
> "Generate a chat widget with quick reply buttons: 'Track my order', 'Start a return', 'Product question'"

**Interactive Demo:**
> "Create an interactive chat demo where I can type messages and the agent responds with preset answers"

**Static Screenshot:**
> "Generate a static chat mockup showing a complete order status conversation for a presentation slide"

---

## Brand Guidelines

This skill follows Gladly's brand guidelines:
- **Primary font**: Helvetica Neue
- **Colors**: Black (#000000), White (#FFFFFF), Gray 200 (#F1F1F1), Gray 300 (#E3E3E3), Gray 400 (#CECECE), Gray 700 (#767676), Gray 800 (#484848)
- **Accent Green**: #009B00 (links), #00A300 (privacy policy links)
- **Design principle**: Clean, simple, people-focused

---

## Icons Reference

### Header Back Arrow
```html
<svg xmlns="http://www.w3.org/2000/svg" width="8" height="12" viewBox="0 0 8 12" fill="none">
  <path fill-rule="evenodd" clip-rule="evenodd" d="M6.87223 11.8648C6.67643 12.0451 6.35899 12.0451 6.16319 11.8648L0.146846 6.32636C-0.0489483 6.14611 -0.0489482 5.85388 0.146846 5.67364L6.1632 0.135181C6.35899 -0.0450612 6.67643 -0.0450611 6.87223 0.135181C7.06802 0.315424 7.06802 0.607653 6.87223 0.787896L1.2104 6L6.87223 11.2121C7.06802 11.3923 7.06802 11.6846 6.87223 11.8648Z" fill="black"/>
</svg>
```

### Header Close/Minimize
```html
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="12" viewBox="0 0 16 12" fill="none">
  <path fill-rule="evenodd" clip-rule="evenodd" d="M0 6.5C0 6.22386 0.238781 6 0.533333 6H15.4667C15.7612 6 16 6.22386 16 6.5C16 6.77614 15.7612 7 15.4667 7H0.533333C0.238781 7 0 6.77614 0 6.5Z" fill="black"/>
</svg>
```

### Footer Attachment Icon
```html
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
  <path fill-rule="evenodd" clip-rule="evenodd" d="M7.11111 1.55127C7.11111 1.20386 7.02967 0.908365 6.87306 0.668454C6.71693 0.429261 6.50612 0.275989 6.29694 0.179346C5.90774 -0.000465976 5.48381 -0.000129227 5.31093 8.04897e-06L5.29772 1.52015e-05C4.73711 1.52015e-05 4.27996 0.216756 3.97331 0.601377C3.67762 0.972248 3.55556 1.45583 3.55556 1.9458V2.66667H2.66699L2.39355 2.68034C1.04909 2.81711 0 3.9531 0 5.33366V11.5553C0 12.9359 1.04908 14.0719 2.39355 14.2087L2.66699 14.2223H4.59622C4.93329 15.1758 5.7971 15.8806 6.83795 15.9864L7.11139 16.0001H13.3331L13.6055 15.9864C14.8609 15.8591 15.8591 14.861 15.9864 13.6056L16.0001 13.3331V7.11144C16.0001 5.63868 14.8058 4.44444 13.3331 4.44444H11.4038C11.0375 3.40878 10.0496 2.66667 8.88867 2.66667H4.44444V1.9458C4.44444 1.59127 4.53385 1.32418 4.66833 1.15551C4.79185 1.00058 4.98356 0.888904 5.29772 0.888904C5.47637 0.888904 5.72473 0.894152 5.92413 0.986277C6.0144 1.02799 6.08166 1.08224 6.12873 1.15434C6.17532 1.22572 6.22222 1.34528 6.22222 1.55127C6.22222 1.79673 6.42121 1.99572 6.66667 1.99572C6.91213 1.99572 7.11111 1.79673 7.11111 1.55127ZM3.55556 3.55534V8.30118C3.55556 9.07072 4.33557 9.77779 5.30564 9.77779C6.27572 9.77779 7.05573 9.07072 7.05573 8.30118V5.23025C7.05573 4.98479 6.85674 4.7858 6.61128 4.7858C6.36582 4.7858 6.16684 4.98479 6.16684 5.23025V8.30118C6.16684 8.46997 5.90234 8.8889 5.30564 8.8889C4.70894 8.8889 4.44444 8.46997 4.44444 8.30118V3.55534H8.88867C9.87051 3.55534 10.667 4.35182 10.667 5.33366V11.5553C10.667 12.5372 9.87051 13.3337 8.88867 13.3337H2.66699C1.68515 13.3337 0.888672 12.5372 0.888672 11.5553V5.33366C0.888672 4.35182 1.68515 3.55534 2.66699 3.55534H3.55556ZM8.88867 14.2223H5.57115C5.87872 14.7538 6.45343 15.1114 7.11139 15.1114H13.3331C14.3149 15.1114 15.1114 14.315 15.1114 13.3331V7.11144C15.1114 6.1296 14.3149 5.33312 13.3331 5.33312H11.5557V5.33366V11.5553L11.542 11.8278C11.4147 13.0832 10.4165 14.0814 9.16113 14.2087L8.88867 14.2223Z" fill="black"/>
</svg>
```

### Footer Send Arrow
```html
<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 15 15" fill="none">
  <path d="M6.64648 0.146484C6.84175 -0.0487778 7.15825 -0.0487778 7.35352 0.146484L14.3535 7.14648C14.5488 7.34175 14.5488 7.65825 14.3535 7.85352L7.35352 14.8535C7.15825 15.0488 6.84175 15.0488 6.64648 14.8535C6.45122 14.6583 6.45122 14.3417 6.64648 14.1465L12.793 8H0.5C0.223858 8 0 7.77614 0 7.5C0 7.22386 0.223858 7 0.5 7H12.793L6.64648 0.853516C6.45122 0.658253 6.45122 0.341747 6.64648 0.146484Z" fill="black"/>
</svg>
```

### Order Card Truck Icon
```html
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="13" viewBox="0 0 16 13" fill="none">
  <path d="M15.6 9.34375C15.8 9.34375 16 9.54688 16 9.75V10.1562C16 10.3848 15.8 10.5625 15.6 10.5625H14.4C14.4 11.9082 13.325 13 12 13C10.675 13 9.6 11.9082 9.6 10.5625H6.4C6.4 11.9082 5.325 13 4 13C2.675 13 1.6 11.9082 1.6 10.5625H1.4C0.625 10.5625 0 9.92773 0 9.14062V1.42188C0 0.660156 0.625 0 1.4 0H9C9.75 0 10.4 0.660156 10.4 1.42188V2.4375H11.3C11.775 2.4375 12.225 2.64062 12.575 2.99609L14.65 5.10352C15 5.45898 15.2 5.91602 15.2 6.39844V9.34375H15.6ZM4 11.7812C4.65 11.7812 5.2 11.248 5.2 10.5625C5.2 9.90234 4.65 9.34375 4 9.34375C3.325 9.34375 2.8 9.90234 2.8 10.5625C2.8 11.248 3.325 11.7812 4 11.7812ZM9.2 9.34375V1.42188C9.2 1.32031 9.1 1.21875 9 1.21875H1.4C1.275 1.21875 1.2 1.32031 1.2 1.42188V9.14062C1.2 9.26758 1.275 9.34375 1.4 9.34375H1.925C2.325 8.63281 3.1 8.125 4 8.125C4.875 8.125 5.65 8.63281 6.05 9.34375H9.2ZM10.4 3.65625V5.6875H13.55L11.725 3.83398C11.6 3.73242 11.45 3.65625 11.3 3.65625H10.4ZM12 11.7812C12.65 11.7812 13.2 11.248 13.2 10.5625C13.2 9.90234 12.65 9.34375 12 9.34375C11.325 9.34375 10.8 9.90234 10.8 10.5625C10.8 11.248 11.325 11.7812 12 11.7812ZM14 9.24219V6.90625H10.4V8.75977C10.825 8.37891 11.375 8.125 12 8.125C12.825 8.125 13.55 8.58203 14 9.24219Z" fill="black"/>
</svg>
```

---

## Template File

A complete HTML template with all components is available at:
`chat-template.html`

This template includes working examples of all message types, cards, and components that can be customized for your specific demo needs.
