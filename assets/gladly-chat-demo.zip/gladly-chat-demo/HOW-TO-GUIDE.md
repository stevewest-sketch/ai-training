# Gladly Chat Demo Generator - How-To Guide

## Overview

This skill helps GTM and Sales team members create pixel-perfect Gladly Chat UI mockups without needing Figma access or design skills. Simply describe what you need, and Claude will generate ready-to-use HTML prototypes.

---

## Quick Start

Just tell Claude what you need:

> "Create a Gladly chat demo showing a customer asking about order status"

Claude will ask you a few quick questions to customize your demo, then generate the HTML file.

---

## Guided Setup Process

When you request a chat demo, Claude will ask you the following questions to ensure the output matches your needs:

### 1. What's the conversation about?

Describe the scenario or provide your own dialogue:
- **Scenario description**: "Customer asking about a delayed shipment"
- **Specific dialogue**: Provide exact messages you want displayed
- **Use case**: "Product recommendation flow for trail running shoes"

### 2. Presentation Mode

| Mode | Description | Best For |
|------|-------------|----------|
| **Static (animated)** | The conversation plays out automatically - messages appear one by one with typing indicators between agent responses. Great for recording. | GIFs, videos, presentations |
| **Interactive** | You control the conversation - type messages and press Send/Enter to add them to the chat. Agent messages are pre-loaded. | Live demos, walkthroughs |

### 3. Which components do you need?

Select any that apply:
- [ ] **Product Cards** - Product recommendations with images
- [ ] **Order Card** - Order status with delivery date, tracking info
- [ ] **Privacy Policy** - Legal text at top of chat
- [ ] **Powered by Gladly** - Branding at bottom

### 4. Component Details (based on your selections)

**If you selected Product Cards:**
- How many cards? **2 cards** (side by side) or **4 cards** (two rows)
- For each product: provide the **product name** and **image URL**
  - To get an image URL: right-click the product image → "Copy Image Address"

**If you selected Order Card:**
- Order number, delivery status, delivery date, tracking number (optional)

### 5. Agent Message Style

| Style | Description | Best For |
|-------|-------------|----------|
| **With bubble** | Agent messages inside a rounded bubble container | Showcasing the existing chat experience, general support conversations |
| **Without bubble** | Plain text without container | Product recommendation conversations - keeps UI clean when showing product cards |

**Recommendations:**
- Choose **"With bubble"** if you want to showcase a typical back-and-forth chat experience
- Choose **"Without bubble"** if your demo focuses on product recommendations with product cards

**Note:** You can mix both styles in the same conversation. For example, use bubbles for greeting messages and plain text for messages that accompany product/order cards.

### 6. Placement Style

| Style | Description |
|-------|-------------|
| **Centered** | Chat UI centered on a solid background color |
| **Widget** | Bottom-right corner, overlaid on a website screenshot |

**If you choose Centered:**
- You'll be asked for a background color hex code (e.g., `#1a1a1a` for dark, `#ffffff` for white)

**If you choose Widget:**
- Please provide a screenshot of the webpage where you want the widget to appear
- Image should be **1440x810 pixels** for best results

### 7. Output Format

| Format | Use Case |
|--------|----------|
| **HTML file** | Open in browser, take screenshots, record GIFs/videos |
| **Screenshot-ready** | Clean static view optimized for slides |

---

## Example Prompts

### Basic Customer Service Chat
> "Create a chat demo where a customer asks about return policy and the agent explains the 30-day return window"

### Order Tracking with Order Card
> "Generate a chat showing order tracking. Include an order card with delivery date Aug 15, order #GLD-12345, and USPS tracking"

### Product Recommendations
> "Create a demo where the agent recommends two trail running shoes using product cards - Hoka Speedgoat and Brooks Cascadia"

### Interactive Demo for Sales Call
> "I need an interactive chat demo for a sales presentation where I can type customer questions live"

### Quick Replies Flow
> "Show a chat with quick reply buttons: 'Track Order', 'Returns', 'Product Question' - then show what happens when someone clicks Track Order"

---

## Tips for Best Results

### Be Specific
Instead of: "Create a chat about orders"
Try: "Create a chat where customer asks about delayed order #12345, agent apologizes and provides new delivery date of Friday"

### Mention Components
If you want product cards, order cards, or quick replies - mention them explicitly.

### Specify Timing (for Static Mode)
For GIF recordings, you can request timing adjustments:
> "Make the typing indicator show for 3 seconds instead of the default"

**Default timing values:**
- Typing indicator duration: 2000ms (2 seconds)
- Delay between messages: 800ms
- Consumer typing delay: 900ms
- Message fade-in animation: 0.5s
- Typing indicator fade: 0.3s in, 0.25s out

### Provide Real Content
For more realistic demos, provide:
- Actual product names and images
- Real order numbers (or realistic fake ones)
- Specific dates and tracking numbers

### Product Image URLs
To get product image URLs:
1. Find the product on the website
2. Right-click on the product image
3. Select "Copy Image Address" (or similar option)
4. Provide this URL when Claude asks for product images

---

## What You'll Receive

Claude will generate:

1. **Complete HTML file** - Self-contained, no dependencies
2. **Ready to use** - Just open in any browser
3. **Customized content** - Your exact conversation and components
4. **Proper styling** - Matches Gladly's design system exactly

**Example demos** are available in the `demos/` folder for reference:
- `product-recommendation-demo.html` - 4 product cards with animated conversation
- `wide-foot-trail-shoes-demo.html` - Product recommendation flow example

### To Use the Output:
1. Save the HTML Claude provides to a file (e.g., `demo.html`)
2. Open in Chrome, Safari, or any browser
3. **For screenshots**: Just capture the browser window
4. **For GIFs**: Use a screen recording tool (e.g., Kap, LICEcap, or built-in)
5. **For live demos**: Open the file and interact with it

---

## Frequently Asked Questions

### Can I edit the demo after it's generated?
Yes! The HTML file is editable. You can:
- Change message text directly in the HTML
- Swap product images by updating the `src` URLs
- Adjust timing in the `<script>` section

### Can I use my own product images?
Absolutely. Just provide the image URLs when requesting the demo, or replace them in the generated HTML.

### How do I record a GIF?
1. Open the HTML file in your browser
2. Refresh to restart the animation
3. Use a screen recording tool to capture the chat area
4. Export as GIF

### Can I embed this in a presentation?
Yes! Options:
- Take a screenshot and insert as an image
- Record a GIF and insert (PowerPoint/Google Slides support GIFs)
- For Notion/web: embed the HTML directly or use a screenshot

### What if I need a different conversation flow?
Just ask Claude to regenerate with your new requirements. Each request creates a fresh demo.

---

## Need Help?

If you're unsure what to ask for, just say:
> "I need a Gladly chat demo for [your use case]"

Claude will guide you through the options!
