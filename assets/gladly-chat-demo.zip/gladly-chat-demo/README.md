# Gladly Chat Demo Generator

## Quick Start Guide for GTM & Sales Teams

Create pixel-perfect Gladly Chat mockups for your demos and presentations in seconds—no design tools required.

---

## What You Can Create

| Output Type | Best For |
|-------------|----------|
| **HTML Prototype** | Live demos, interactive presentations |
| **Static Mockup** | PowerPoint slides, Google Slides, PDFs |
| **GIF Sequence** | Animated walkthroughs, social media |

---

## How to Use

### Step 1: Open Claude Code

Launch Claude Code in your terminal or IDE.

### Step 2: Describe What You Need

Just tell Claude what you want. Be specific about:
- **The conversation** - What scenario are you showing?
- **The placement** - Centered (focused demo) or widget (website context)
- **Special features** - Quick replies, typing indicator, timestamps

### Step 3: Get Your Output

Claude will generate complete HTML code. You can:
- Open it in a browser to preview
- Screenshot it for slides
- Record it for GIFs

---

## Example Prompts

### Simple Order Inquiry
```
Create a Gladly chat demo where a customer asks "Where's my order?"
and the agent responds with shipping status and tracking link.
```

### With Quick Replies
```
Generate a chat mockup with the greeting "Hi! How can I help?"
and quick reply buttons for: Track order, Start return, Ask a question
```

### Return Request Flow
```
Build a 4-message conversation:
1. Agent: "How can I help you today?"
2. Customer: "I need to return my jacket"
3. Agent: "I'd be happy to help! What's the reason for the return?"
4. Customer: "It doesn't fit right"
```

### GIF Sequence
```
Create a 5-frame GIF sequence showing:
Frame 1: Agent greeting with quick replies
Frame 2: Customer selects "Track my order"
Frame 3: Typing indicator
Frame 4: Agent asks for order number
Frame 5: Agent provides tracking info
```

### Widget on Website
```
Create a chat widget mockup positioned bottom-right, showing a
proactive message: "Having trouble finding something? I'm here to help!"
```

---

## Viewing Your Mockup

### Option 1: Browser Preview
1. Copy the HTML code Claude generates
2. Save it as `demo.html` on your computer
3. Double-click to open in Chrome/Safari/Firefox

### Option 2: Direct Screenshot
1. Open the HTML in browser
2. Use browser screenshot (Cmd+Shift+4 on Mac)
3. Paste into your presentation

### Option 3: Online Preview
1. Go to [CodePen](https://codepen.io/pen/) or [JSFiddle](https://jsfiddle.net/)
2. Paste the HTML into the HTML panel
3. View instant preview

---

## Creating GIFs

### Using macOS Built-in Screen Recording
1. Press `Cmd + Shift + 5`
2. Select "Record Selected Portion"
3. Frame around the chat widget
4. Click Record, then scroll through frames
5. Convert to GIF using [ezgif.com](https://ezgif.com/video-to-gif)

### Using Gifski (Free Mac App)
1. Download [Gifski](https://gif.ski/) from App Store
2. Record your screen or take sequential screenshots
3. Drag into Gifski to create high-quality GIF

### Timing Recommendations
| Frame Type | Duration |
|------------|----------|
| Message appears | 1.5 - 2 seconds |
| Typing indicator | 1 - 1.5 seconds |
| Quick replies | 2 seconds |
| Final state | 3+ seconds |

---

## Customization Tips

### Change the Header Title
Find this line and edit the text:
```html
<span class="gladly-chat-header-title">Let's Chat!</span>
```

### Add/Remove Messages
Copy this block for a new agent message:
```html
<div class="gladly-message-group gladly-message-group-agent">
  <div class="gladly-message gladly-message-agent">
    Your message here
  </div>
  <div class="gladly-timestamp">1:15 pm</div>
</div>
```

Copy this block for a new customer message:
```html
<div class="gladly-message-group gladly-message-group-consumer">
  <div class="gladly-message gladly-message-consumer">
    Customer message here
  </div>
  <div class="gladly-timestamp">1:16 pm</div>
</div>
```

### Add Quick Reply Buttons
```html
<div class="gladly-quick-replies">
  <button class="gladly-quick-reply-btn">Button 1</button>
  <button class="gladly-quick-reply-btn">Button 2</button>
  <button class="gladly-quick-reply-btn">Button 3</button>
</div>
```

### Add Typing Indicator
```html
<div class="gladly-typing-indicator">
  <div class="gladly-typing-dot"></div>
  <div class="gladly-typing-dot"></div>
  <div class="gladly-typing-dot"></div>
</div>
```

### Change Background Color
Find this line in the CSS and change the color:
```css
background: #1a1a1a;  /* Dark background */
```
Options:
- `#1a1a1a` - Dark (default)
- `#ffffff` - White
- `#f5f5f5` - Light gray

---

## Common Scenarios

### 1. Sales Demo: Order Tracking
Show how easily customers can check order status:
```
Customer: "Where's my order?"
Agent: "I can help! What's your order number?"
Customer: "#12345"
Agent: "Your order shipped yesterday and arrives Friday! Here's your tracking: [link]"
```

### 2. Product Demo: AI-Assisted Response
Highlight Sidekick capabilities:
```
Customer: "Do you have this jacket in blue?"
Agent: "Yes! The Alpine Puffer is available in Blue in sizes S-XL. Would you like me to check a specific size?"
```

### 3. Marketing: Proactive Engagement
Show proactive messaging:
```
Agent: "I noticed you've been browsing winter boots. Can I help you find the perfect pair?"
[Quick Replies: Show me bestsellers | I need waterproof boots | Just browsing]
```

### 4. Case Study: Complex Resolution
Demonstrate multi-step problem solving:
```
Customer: "My order arrived damaged"
Agent: "I'm so sorry about that! Let me make this right immediately."
Agent: "I've just processed a replacement order at no charge. It'll ship today with express delivery. You'll receive tracking within the hour."
Customer: "Wow, that was fast! Thank you!"
```

---

## Troubleshooting

### Mockup looks different than expected
- Make sure you copied the ENTIRE HTML code, including `<!DOCTYPE html>`
- Use a modern browser (Chrome, Safari, Firefox)

### Fonts look wrong
- The template uses Helvetica Neue, which is standard on Mac
- On Windows, it falls back to Helvetica, then Arial

### Colors don't match exactly
- These are the official Gladly colors from the design system
- If comparing to production, there may be minor variations

### Need the Figma source files?
Contact the design team or access directly:
- [Centered Chat UI](https://www.figma.com/design/xdhBksSnd3E58aGwiyqDOL/Glad-App-Prototyping-Template?node-id=1372-7809)
- [Widget Placement](https://www.figma.com/design/xdhBksSnd3E58aGwiyqDOL/Glad-App-Prototyping-Template?node-id=722-7931)

---

## Questions?

This skill was created to help GTM and Sales teams quickly create on-brand Gladly Chat visuals. If you need help or have feature requests, reach out to the team that built this.

Happy demo-ing! 🎉
